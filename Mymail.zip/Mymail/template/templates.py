import os

"""
/abc/ad/file.txt  (for windows)
\hi\this\is\a\file.txt (for linux)

open("\hi\thi\is\a\file.txxt").read()

open("/abc/ad/file.txxt").read()
""" 
def get_template_path(path):
	file_path = os.path.join(os.getcwd(), path)
	if not os.path.isfile(file_path):
		raise Exception("This is not a valid Template path %s"%(file_path))
	return file_path

def get_template(path):
	file_path = get_template_path(path)
	return open(file_path).read()

#format_ = raw_input("Which type of mail do you want to send (html/text) : ")
file_  = 'message/email_message.txt'
file_html = 'message/email_message.html'



template_text = get_template(file_)
template_html = get_template(file_html)
#print(template_html)
os.getcwd()



