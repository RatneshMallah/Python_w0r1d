import os

"""
/abc/ad/file.txt  (for windows)
\hi\this\is\a\file.txt (for linux)

open("\hi\thi\is\a\file.txxt").read()

open("/abc/ad/file.txxt").read()
""" 
def get_template_path(path):
	file_path = os.path.join(os.getcwd(), path)
	if not os.path.isfile(file_path):
		raise Exception("This is not a valid Template path %s"%(file_path))
	return file_path

def get_template(path):
	file_path = get_template_path(path)
	return open(file_path).read()

file_  = 'message/mailid.txt'
#file_html = 'message/email_message.html'



mailid = (get_template(file_)).split(',')
#template_html = get_template(file_html)
#print(template_html)
os.getcwd()



