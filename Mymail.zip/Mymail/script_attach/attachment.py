import os 
from os import listdir

attachment_path = os.path.join(os.getcwd(),'Attachments' )
"""for file in os.listdir(attachment_path):
	attchment_files = file
	#print(attchment_files)
"""