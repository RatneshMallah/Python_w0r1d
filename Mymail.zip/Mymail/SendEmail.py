import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from smtplib import SMTPAuthenticationError
from template.templates import *
from mail.mailid import *
from script_attach.attachment import *
from email.MIMEBase import MIMEBase
from email import encoders
import getpass



host = "smtp.gmail.com"
port = 587
username = raw_input("Enter mail id : ")
password = getpass.getpass("Enter your password : ")
from_email = username
to_list = mailid
#print(to_list)

try:
	email_conn = smtplib.SMTP(host, port)
	email_conn.ehlo()
	email_conn.starttls()
	email_conn.login(username, password)
	the_msg = MIMEMultipart()
	the_msg["From"] = from_email
	#the_msg["To"] = to_list[0]
	plain_text = "Website and Web application Development"
	while True:
		msg_format = raw_input("Message format(html/text) : ")
		if msg_format == 'html':
			html_text = "{template_html}".format(template_html=template_html)
			the_msg['Subject'] = raw_input("Enter a mail subject : ")
			part_1 = MIMEText(html_text, 'html')
			the_msg.attach(part_1)
			break	
		elif msg_format == 'text':																								
			html_text = "template_text".format(template_text=template_text)
			the_msg['Subject'] = raw_input("Enter a mail subject : ")
			part_2 = MIMEText(plain_text, 'plain')
			the_msg.attach(part_2)
			break
		else:
			print "Incorrect message format '%s' "%(msg_format)
	
	
	#Attachment_Part
	#attachment_path = os.path.join(os.getcwd(),'Attachments')
	send_attachment = raw_input("Do you want to send attachment 'Y/N' : ")
	if send_attachment == 'Y' or send_attachment == 'y' or send_attachment == 'Yes' or send_attachment == 'yes':
		for files in os.listdir(attachment_path):
			st1, st2 = os.path.splitext(files)
			filename = st1+st2
			attachment = open(attachment_path+'/'+files, "rb")
			print(attachment)
			part = MIMEBase('application', 'octet-stream')
			part.set_payload((attachment).read())
			encoders.encode_base64(part)
			part.add_header('Content-Disposition', "attachment; filename= %s" % filename)
			the_msg.attach(part)
	else:
		print("No attachments added")

	"""attachment_ = open(attachment_path, "rb")
	for file in os.listdir(attachment_path):
		attchment_files = file
		part_3 = MIMEBase('application', 'octet-stream')
		part_3.set_paylod((attachment_).read())
		encoders.encode_base64(part_3)
		part_3.add_header('Content-Disposition', "attachment_; filename= %s" % attchment_files)
		the_msg.attach(part_3)
	"""

	email_conn.sendmail(from_email, to_list, the_msg.as_string())
	#print(to_list)
	print("sent!")
	email_conn.quit()
except SMTPAuthenticationError:
	print("authrnticatin error")
	email_conn.quit()
except:
	print("sending message error")
	email_conn.quit()

#print(attachment_path)
